# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
npm install        # install dependencies
npm run build      # compile TypeScript → build/
npm run dev        # watch mode (recompile on save)
npm start          # run MCP server directly (needs ELEVENLABS_API_KEY)
npm run client     # run interactive CLI client (needs API keys — see below)
```

There are no tests in this project.

## Environment Variables

Both `src/index.ts` and `src/client.ts` start with `import "dotenv/config"`, so a `.env` file in the project root is loaded automatically — no need to export vars manually if `.env` is present (see `.env.example` for the template).

| Variable | Required | Notes |
|---|---|---|
| `ELEVENLABS_API_KEY` | Always | ElevenLabs REST API key |
| `LLM_PROVIDER` | No | `"anthropic"` (default) or `"openai"` |
| `ANTHROPIC_API_KEY` | If using Anthropic | Claude API key |
| `OPENAI_API_KEY` | If using OpenAI | GPT API key |
| `ELEVENLABS_OUTPUT_DIR` | No | Where MP3 files are saved (defaults to `cwd`) |

## Architecture

Three source files, one responsibility each:

- **`src/elevenlabs-client.ts`** — HTTP wrapper around the ElevenLabs REST API: `listVoices`, `getVoice`, `listModels`, `textToSpeech`, `speechToText`, `getUserInfo`, `getHistory`. `speechToText` sends audio via `FormData`/`Blob` multipart.

- **`src/index.ts`** — MCP server. Registers **7 tools** (`list_voices`, `get_voice`, `list_models`, `text_to_speech`, `speech_to_text`, `get_user_info`, `get_history`), **4 prompts** (`voice_agent_persona`, `start_voice_session`, `find_voice_for_role`, `voice_showcase`), and **2 resources** (`elevenlabs://voices`, `elevenlabs://models`). Uses `server.registerTool` and `server.registerPrompt` (non-deprecated API from SDK v1.29+). Communicates over stdio.

- **`src/client.ts`** — CLI client. Spawns `build/index.js` as a child process, connects to Claude or GPT, runs an interactive REPL. REPL commands: `/prompts` (list), `/prompt <name> [key=value]` (invoke), `/voice` (enter voice loop), `exit`. Voice loop: records mic via `sox rec` → calls `speech_to_text` tool → calls LLM with `VOICE_SYSTEM` override → parses `"Audio saved to: /path.mp3"` from tool output → plays via `afplay` (macOS) / `mpg123` (Linux). LLM model IDs are hardcoded: `claude-sonnet-4-20250514` (Anthropic) and `gpt-4o` (OpenAI) — update these directly in `chatAnthropic`/`chatOpenAI` when models deprecate.

## MCP Primitives

| Primitive | Count | Registered via |
|---|---|---|
| Tools | 7 | `server.registerTool(name, { description, inputSchema }, handler)` |
| Prompts | 4 | `server.registerPrompt(name, { description, argsSchema }, handler)` |
| Resources | 2 | `server.resource(name, uri, { description, mimeType }, handler)` |

## TypeScript Notes

- `"module": "Node16"` with `"type": "module"` in `package.json` — import paths must use `.js` extension even for `.ts` source files.
- Compiled output goes to `build/`; both `npm start` and `npm run client` run from there.
- `Buffer` cannot be passed directly to `Blob` — use `new Uint8Array(buffer)` instead.
- `text_to_speech` defaults to voice `21m00Tcm4TlvDq8ikWAM` (Rachel) and model `eleven_multilingual_v2` when `voice_id`/`model_id` are omitted (see `src/index.ts`).

## System Prerequisites for Voice Mode

- `sox` must be installed for microphone recording (`brew install sox` on macOS, `apt install sox` on Linux).
- Audio playback uses `afplay` (macOS built-in) or `mpg123` (Linux).

## Further Documentation

- `Explanation/00-reading-order.md` and the numbered files after it — line-by-line walkthroughs of `elevenlabs-client.ts`, `index.ts`, and `client.ts`.
- `prompt.md` — usage guide for the 4 MCP prompts (recommended invocation order, arguments, expected output).
- `GUIDE.md` / `DEMO.md` — project overview and example sessions.
